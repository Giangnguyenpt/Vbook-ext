var adblockUrls = [
    //"https://s3.mideman.com/file/mideman/cmanga/chapter/397424/47.png?v=12",
    // Các URL quảng cáo khác...
"https://s3.mideman.com/file/mideman/cmanga/chapter/397358/32.png?v=12",
"https://ccmmh.biz/nettruyenvn/pages/profile_image/2684389/page-2684389.jpg",
];