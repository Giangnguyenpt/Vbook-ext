function execute(url) {
    url = url.replace("nettruyen.com", "nhattruyenvn.com");
    url = url.replace("nettruyendie.com", "nhattruyenvn.com");
    url = url.replace("nettruyentt.com", "nhattruyenvn.com");
    url = url.replace("nettruyenvv.com", "nhattruyenvn.com");
    url = url.replace("nettruyencc.com", "nhattruyenvn.com");
    url = url.replace("nettruyengo.com", "nhattruyenvn.com");
    url = url.replace("nettruyenmoi.com", "nhattruyenvn.com");
    url = url.replace("nettruyenone.com", "nhattruyenvn.com");
    url = url.replace("nettruyenco.com", "nhattruyenvn.com");
    url = url.replace("nettruyenssr.com", "nhattruyenvn.com");
    const doc = Http.get(url).html()
    var coverImg = doc.select(".detail-info img").first().attr("src");
    if (coverImg.startsWith("//")) {
        coverImg = "https:" + coverImg
    }
    return Response.success({
        name: doc.select("h1.title-detail").first().text(),
        cover: coverImg,
        author: doc.select(".author a").first().text(),
        description: doc.select(".detail-content p").html(),
        detail: doc.select(".list-info").html(),
        host: "https://www.nhattruyenss.net",
        ongoing: doc.select(".detail-info .status").html().indexOf("Đang tiến hành") >= 0
    });
}