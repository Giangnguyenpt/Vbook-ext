var adblockUrls = [
    //"https://s3.mideman.com/file/mideman/cmanga/chapter/397424/47.png?v=12",
    // Các URL quảng cáo khác...


"https://s3.mideman.com/file/mideman/cmanga/chapter/397358/32.png?v=12",
"https://ccmmh.biz/nettruyenvn/pages/profile_image/2684389/page-2684389.jpg",
"https://storage.anhvip.xyz/image_comics/14605/1355339/img_007_1688735957.jpg",
"https://www.toptruyenvn.pro/images/default/trong-sinh.png",
"https://www.toptruyenvn.pro/images/default/top-banner.jpg",
"top-banner",
"bottom-banner",
"default",
"https://storage.anhvip.xyz/image_comics/9236/573555/img_001_1660549908.jpg?data=3q",
"https://storage.anhvip.xyz/image_comics/9236/573555/img_003_1660549917.jpg?data=3q",


];