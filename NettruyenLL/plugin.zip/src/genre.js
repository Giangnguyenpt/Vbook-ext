function execute() {
    return Response.success([
    {
        "title": "Tất cả thể loại",
        "input": "https://nettruyenll.com/danh-sach-truyen/1",
        "script": "gen.js"
    },
    {
        "title": "Action",
        "input": "https://nettruyenll.com/the-loai/action",
        "script": "gen.js"
    },
    {
        "title": "Adult",
        "input": "https://nettruyenll.com/the-loai/adult",
        "script": "gen.js"
    },
    {
        "title": "Adventure",
        "input": "https://nettruyenll.com/the-loai/adventure",
        "script": "gen.js"
    },
    {
        "title": "Anime",
        "input": "https://nettruyenll.com/the-loai/anime",
        "script": "gen.js"
    },
    {
        "title": "Chuyển Sinh",
        "input": "https://nettruyenll.com/the-loai/chuyen-sinh",
        "script": "gen.js"
    },
    {
        "title": "Cổ Đại",
        "input": "https://nettruyenll.com/the-loai/co-dai",
        "script": "gen.js"
    },
    {
        "title": "Cổ Trang",
        "input": "https://nettruyenll.com/the-loai/co-trang",
        "script": "gen.js"
    },
    {
        "title": "Comedy",
        "input": "https://nettruyenll.com/the-loai/comedy",
        "script": "gen.js"
    },
    {
        "title": "Comic",
        "input": "https://nettruyenll.com/the-loai/comic",
        "script": "gen.js"
    },
    {
        "title": "Demons",
        "input": "https://nettruyenll.com/the-loai/demons",
        "script": "gen.js"
    },
    {
        "title": "Detective",
        "input": "https://nettruyenll.com/the-loai/detective",
        "script": "gen.js"
    },
    {
        "title": "Doujinshi",
        "input": "https://nettruyenll.com/the-loai/doujinshi",
        "script": "gen.js"
    },
    {
        "title": "Drama",
        "input": "https://nettruyenll.com/the-loai/drama",
        "script": "gen.js"
    },
    {
        "title": "Đam Mỹ",
        "input": "https://nettruyenll.com/the-loai/dam-my",
        "script": "gen.js"
    },
    {
        "title": "Ecchi",
        "input": "https://nettruyenll.com/the-loai/ecchi",
        "script": "gen.js"
    },
    {
        "title": "Fantasy",
        "input": "https://nettruyenll.com/the-loai/fantasy",
        "script": "gen.js"
    },
    {
        "title": "Gender Bender",
        "input": "https://nettruyenll.com/the-loai/gender-bender",
        "script": "gen.js"
    },
    {
        "title": "Hài Hước",
        "input": "https://nettruyenll.com/the-loai/hai-huoc",
        "script": "gen.js"
    },
    {
        "title": "Harem",
        "input": "https://nettruyenll.com/the-loai/harem",
        "script": "gen.js"
    },
    {
        "title": "Historical",
        "input": "https://nettruyenll.com/the-loai/historical",
        "script": "gen.js"
    },
    {
        "title": "Horror",
        "input": "https://nettruyenll.com/the-loai/horror",
        "script": "gen.js"
    },
    {
        "title": "Huyền Huyễn",
        "input": "https://nettruyenll.com/the-loai/huyen-huyen",
        "script": "gen.js"
    },
    {
        "title": "Isekai",
        "input": "https://nettruyenll.com/the-loai/isekai",
        "script": "gen.js"
    },
    {
        "title": "Josei",
        "input": "https://nettruyenll.com/the-loai/josei",
        "script": "gen.js"
    },
    {
        "title": "Magic",
        "input": "https://nettruyenll.com/the-loai/magic",
        "script": "gen.js"
    },
    {
        "title": "Manhua",
        "input": "https://nettruyenll.com/the-loai/manhua",
        "script": "gen.js"
    },
    {
        "title": "Manhwa",
        "input": "https://nettruyenll.com/the-loai/manhwa",
        "script": "gen.js"
    },
    {
        "title": "Martial Arts",
        "input": "https://nettruyenll.com/the-loai/martial-arts",
        "script": "gen.js"
    },
    {
        "title": "Mature",
        "input": "https://nettruyenll.com/the-loai/mature",
        "script": "gen.js"
    },
    {
        "title": "Mystery",
        "input": "https://nettruyenll.com/the-loai/mystery",
        "script": "gen.js"
    },
    {
        "title": "Ngôn Tình",
        "input": "https://nettruyenll.com/the-loai/ngon-tinh",
        "script": "gen.js"
    },
    {
        "title": "One Shot",
        "input": "https://nettruyenll.com/the-loai/one-shot",
        "script": "gen.js"
    },
    {
        "title": "Psychological",
        "input": "https://nettruyenll.com/the-loai/psychological",
        "script": "gen.js"
    },
    {
        "title": "Romance",
        "input": "https://nettruyenll.com/the-loai/romance",
        "script": "gen.js"
    },
    {
        "title": "School Life",
        "input": "https://nettruyenll.com/the-loai/school-life",
        "script": "gen.js"
    },
    {
        "title": "Sci-Fi",
        "input": "https://nettruyenll.com/the-loai/sci-fi",
        "script": "gen.js"
    },
    {
        "title": "Seinen",
        "input": "https://nettruyenll.com/the-loai/seinen",
        "script": "gen.js"
    },
    {
        "title": "Shoujo",
        "input": "https://nettruyenll.com/the-loai/shoujo",
        "script": "gen.js"
    },
    {
        "title": "Shoujo Ai",
        "input": "https://nettruyenll.com/the-loai/shoujo-ai",
        "script": "gen.js"
    },
    {
        "title": "Shounen",
        "input": "https://nettruyenll.com/the-loai/shounen",
        "script": "gen.js"
    },
    {
        "title": "Shounen Ai",
        "input": "https://nettruyenll.com/the-loai/shounen-ai",
        "script": "gen.js"
    },
    {
        "title": "Slice Of Life",
        "input": "https://nettruyenll.com/the-loai/slice-of-life",
        "script": "gen.js"
    },
    {
        "title": "Smut",
        "input": "https://nettruyenll.com/the-loai/smut",
        "script": "gen.js"
    },
    {
        "title": "Sports",
        "input": "https://nettruyenll.com/the-loai/sports",
        "script": "gen.js"
    },
    {
        "title": "Supernatural",
        "input": "https://nettruyenll.com/the-loai/supernatural",
        "script": "gen.js"
    },
    {
        "title": "Tragedy",
        "input": "https://nettruyenll.com/the-loai/tragedy",
        "script": "gen.js"
    },
    {
        "title": "Trọng Sinh",
        "input": "https://nettruyenll.com/the-loai/trong-sinh",
        "script": "gen.js"
    },
    {
        "title": "Truyện Màu",
        "input": "https://nettruyenll.com/the-loai/truyen-mau",
        "script": "gen.js"
    },
    {
        "title": "Webtoon",
        "input": "https://nettruyenll.com/the-loai/webtoon",
        "script": "gen.js"
    }]);
}
    