load('config.js');
load('adblock.js');

let adblock = adblockUrls;

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let servers = [];
        doc.select("div[data-server]").forEach(div => {
            let server = parseInt(div.attr("data-server"));
            if (!servers.includes(server)) {
                servers.push(server);
            }
        });

        let bestServer = null;
        let bestPointRate = 0;

        if (servers.length >= 3) {
            let server3 = 3;
            let serverUrl = url.replace(/data-server="\d+"/, `data-server="${server3}"`);
            let tempUrlCheck = [];
            let inaccessibleCount = 0;
            const MAX_INACCESSIBLE = 5;

            doc.select("div[id^='page_']").forEach(div => {
                let img = div.select("img");

                img.forEach(e => {
                    let src = e.attr("src");
                    let dataSrc = e.attr("data-src");

                    if (src && !adblock.includes(src)) tempUrlCheck.push(src);
                    if (dataSrc && !adblock.includes(dataSrc)) tempUrlCheck.push(dataSrc);
                });
            });

            let accessibleCount = 0;
            let totalCount = tempUrlCheck.length;

            for (let url of tempUrlCheck) {
                if (!checkImageUrl(url)) {
                    inaccessibleCount++;
                    if (inaccessibleCount > MAX_INACCESSIBLE) {
                        break;
                    }
                } else {
                    accessibleCount++;
                }
            }

            let pointRate = (accessibleCount / totalCount) * 100;
            if (pointRate >= 50) {
                bestServer = server3;
                bestPointRate = pointRate;
            } else {
                servers = servers.filter(server => server !== 3);
            }
        }

        if (!bestServer) {
            let serverPoints = servers.map(server => {
                let serverUrl = url.replace(/data-server="\d+"/, `data-server="${server}"`);
                let tempUrlCheck = [];
                let inaccessibleCount = 0;
                const MAX_INACCESSIBLE = 5;

                doc.select("div[id^='page_']").forEach(div => {
                    let img = div.select("img");

                    img.forEach(e => {
                        let src = e.attr("src");
                        let dataSrc = e.attr("data-src");

                        if (src && !adblock.includes(src)) tempUrlCheck.push(src);
                        if (dataSrc && !adblock.includes(dataSrc)) tempUrlCheck.push(dataSrc);
                    });
                });

                let accessibleCount = 0;
                let totalCount = tempUrlCheck.length;

                for (let url of tempUrlCheck) {
                    if (!checkImageUrl(url)) {
                        inaccessibleCount++;
                        if (inaccessibleCount > MAX_INACCESSIBLE) {
                            return { server, pointRate: 1 };
                        }
                    } else {
                        accessibleCount++;
                    }
                }

                let pointRate = (accessibleCount / totalCount) * 100;
                return { server, pointRate };
            });

            let bestServerPoint = serverPoints.reduce((max, server) => server.pointRate > max.pointRate ? server : max, { pointRate: 0 });
            bestServer = bestServerPoint.server;
            bestPointRate = bestServerPoint.pointRate;

            if (bestPointRate <= 1) {
                serverPoints = servers.map(server => {
                    let serverUrl = url.replace(/data-server="\d+"/, `data-server="${server}"`);
                    let tempUrlCheck = [];

                    doc.select("div[id^='page_']").forEach(div => {
                        let img = div.select("img");

                        img.forEach(e => {
                            let src = e.attr("src");
                            let dataSrc = e.attr("data-src");

                            if (src && !adblock.includes(src)) tempUrlCheck.push(src);
                            if (dataSrc && !adblock.includes(dataSrc)) tempUrlCheck.push(dataSrc);
                        });
                    });

                    let accessibleCount = 0;
                    let totalCount = tempUrlCheck.length;

                    tempUrlCheck.forEach(url => {
                        if (checkImageUrl(url)) {
                            accessibleCount++;
                        }
                    });

                    let pointRate = (accessibleCount / totalCount) * 100;
                    return { server, pointRate };
                });

                bestServerPoint = serverPoints.reduce((max, server) => server.pointRate > max.pointRate ? server : max, { pointRate: 0 });
                bestServer = bestServerPoint.server;
                bestPointRate = bestServerPoint.pointRate;
            }
        }

        let bestData = fetchServerData(url, bestServer);
        return Response.success(bestData);
    }
    return null;
}

function fetchServerData(url, server) {
    let response = fetch(url.replace(/data-server="\d+"/, `data-server="${server}"`));
    let doc = response.html();
    let tempData = [];

    doc.select("div[id^='page_']").forEach(div => {
        let id = div.attr("id");
        let pageNumber = parseInt(id.replace('page_', ''));
        let img = div.select("img");

        img.forEach(e => {
            let src = e.attr("src");
            let dataSrc = e.attr("data-src");

            if (src && checkImageUrl(src) && !adblock.includes(src)) {
                tempData.push({ pageNumber: pageNumber, url: src });
            }
            if (dataSrc && checkImageUrl(dataSrc) && !adblock.includes(dataSrc)) {
                tempData.push({ pageNumber: pageNumber, url: dataSrc });
            }
        });
    });

    tempData.sort((a, b) => a.pageNumber - b.pageNumber);
    return tempData.map(page => page.url);
}

function checkImageUrl(url) {
    try {
        let headResponse = fetch(url, {
            method: 'HEAD'
        });

        return headResponse.ok;
    } catch (error) {
        return false;
    }
}