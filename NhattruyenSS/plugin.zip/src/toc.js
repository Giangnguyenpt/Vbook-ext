// Load the Config.js file to get the BASE_URL
load('config.js');

// Function to execute and get unique chapter data
function execute(url) {
    // Replace all nettruyen URLs with the BASE_URL
    url = url.replace(/nettruyen(?:\.com|die\.com|tt\.com|vv\.com|cc\.com|go\.com|moi\.com|one\.com|ssr\.com|me\.com)/g, BASE_URL.replace(/^https?:\/\//, ''));

    // Fetch the HTML content from the URL
    var doc = Http.get(url).html();
    var el = doc.select("div.list-chapter li.row .chapter a");
    
    // Initialize arrays to store chapters
    const seenChapters = new Set();
    const uniqueData = [];

    for (var i = el.size() - 1; i >= 0; i--) {
        var e = el.get(i);
        var chapterText = e.text();
        var chapterNumber = parseFloat(chapterText.replace(/[^\d.]/g, '')); // Convert to float for accurate sorting

        if (!seenChapters.has(chapterNumber)) {
            seenChapters.add(chapterNumber);
            uniqueData.push({
                name: chapterText,
                url: e.attr("href"),
                host: BASE_URL
            });
        }
    }

    // Sort based on numerical value including decimal parts
    uniqueData.sort((a, b) => {
        const numA = parseFloat(a.name.replace(/[^\d.]/g, ''));
        const numB = parseFloat(b.name.replace(/[^\d.]/g, ''));
        return numA - numB;
    });

    return Response.success(uniqueData);
}