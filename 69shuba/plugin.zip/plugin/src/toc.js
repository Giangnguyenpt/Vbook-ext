load(‘libs.js’);
load(‘config.js’);

function execute(url) {
    const regex = /\/(\d+)\.htm/;
    const match = url.match(regex);
    let book_id = match[1];
    console.log(book_id);
    
    let response = fetch(BASE_URL + “/book/“ + book_id + “/“);
    if (response.ok) {
        let doc = response.html(‘gbk’);

        var data = [];
        var elems = $.QA(doc, ‘div.catalog > ul > li > a:not(#bookcase)’);

        elems.forEach(function(e) {
            let chapterName = formatName(e.text());
            let chapterNumber = extractChapterNumber(chapterName); // lấy số chương
            data.push({
                name: chapterName,
                url: e.attr(‘href’),
                host: BASE_URL,
                chapterNumber: chapterNumber  // lưu để sắp xếp
            });
        });

        // Sắp xếp theo số chương tăng dần
        data.sort(function(a, b) {
            return a.chapterNumber - b.chapterNumber;
        });

        // Xóa trường phụ trước khi trả kết quả
        data.forEach(item => delete item.chapterNumber);

        return Response.success(data);
    }
    return null;
}

// “63.第63章 无上极境，诸神共鸣” —> “第63章 无上极境，诸神共鸣”
function formatName(name) {
    var re = /^(\d+)\.第(\d+)章/;
    return name.replace(re, ‘第$2章’);
}

// Trích số chương từ tiêu đề kiểu “第63章 ...”
function extractChapterNumber(name) {
    let match = name.match(/^第(\d+)章/);
    if (match) {
        return parseInt(match[1]);
    }
    return 0; // Mặc định nếu không khớp
}