load('config.js');

function execute() {
    let response = fetch(BASE_URL + "/the-loai/");
    if (response.ok) {
        let doc = response.html();
        let genres = [];
        doc.select(".dropdown-genres option").forEach(e => {
            let value = e.attr("value");
            if (value) { // Kiểm tra nếu giá trị không trống
                genres.push({
                    title: e.text(),
                    input: value,
                    script: "gen.js"
                });
            }
        });
        return Response.success(genres);
    }

    return null;
}