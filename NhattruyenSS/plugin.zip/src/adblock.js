var adblockUrls = [
    //"https://s3.mideman.com/file/mideman/cmanga/chapter/397424/47.png?v=12",
    // Các URL quảng cáo khác...
"https://s3.mideman.com/file/mideman/cmanga/chapter/397358/32.png?v=12",
];