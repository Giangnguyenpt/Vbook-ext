// Load giá trị BASE_URL từ config.js
load('config.js');

// Danh sách các server. Điều chỉnh danh sách này nếu có nhiều server hơn.
const servers = [
    BASE_URL,
    BASE_URL.replace(/server1/, 'server2'),
    BASE_URL.replace(/server1/, 'server3'),
    BASE_URL.replace(/server1/, 'server4')
];

// Hàm để kiểm tra kết nối đến các URL hình ảnh của chapter từ một server
function checkChapterImageUrls(serverUrl, imageUrls) {
    let successfulCount = 0;

    imageUrls.forEach(url => {
        let fullUrl = `${serverUrl}/${url}`;
        try {
            let response = fetch(fullUrl);
            if (response.ok) {
                successfulCount++;
            }
        } catch (error) {
            // Không làm gì nếu lỗi
        }
    });

    return (successfulCount / imageUrls.length) * 100; // Tính điểm phần trăm
}

// Hàm để lấy danh sách các URL hình ảnh của chapter từ trang
function getChapterImageUrlsFromPage(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let urls = [];
        doc.select(".page-chapter img").forEach(e => {
            if (e.attr("src")) {
                urls.push(e.attr("src"));
            }
            if (e.attr("data-src")) {
                urls.push(e.attr("data-src"));
            }
        });
        return urls;
    }
    return [];
}

// Hàm để chọn server có tỷ lệ thành công cao nhất
function selectBestServer(imageUrls) {
    let bestServer = null;
    let bestScore = 0;

    servers.forEach(server => {
        let score = checkChapterImageUrls(server, imageUrls);
        if (score > bestScore) {
            bestScore = score;
            bestServer = server;
        }
    });

    return bestServer;
}

// Hàm chính để thực thi việc lấy ảnh chapter
function execute(url) {
    // Lấy danh sách các URL hình ảnh chapter từ trang
    let chapterImageUrls = getChapterImageUrlsFromPage(url);

    if (chapterImageUrls.length === 0) {
        return Response.error("Không tìm thấy hình ảnh chapter trên trang.");
    }

    // Chọn server tốt nhất dựa trên điểm số
    let bestServer = selectBestServer(chapterImageUrls);

    if (bestServer) {
        // Thay thế URL bằng server tốt nhất
        url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, bestServer.replace(/^https?:\/\//, ''));

        // Lấy ảnh chapter từ server tốt nhất
        let images = getChapterImageUrlsFromPage(url);
        return Response.success(images);
    }

    return Response.error("Không thể tải ảnh từ bất kỳ server nào.");
}