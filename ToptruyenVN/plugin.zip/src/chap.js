load('adblock.js');

function execute(url) {
    var doc = fetch(url).html();
    var el = doc.select(".list-image-detail .page-chapter img");   
    var data = [];

    // Chuyển đổi các phần tử HTML thành một mảng các đối tượng chứa URL và data-index
    var imgArray = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        var src = e.attr("src");
        var index = parseInt(e.attr("data-index"));
        
        imgArray.push({ index: index, src: src });
    }

    // Sắp xếp mảng dựa trên giá trị của data-index
    imgArray.sort((a, b) => a.index - b.index);

    // Lọc bỏ các URL không cần thiết dựa trên adblockUrls
    imgArray.forEach(img => {
        var shouldBlock = adblockUrls.some(adUrl => img.src.includes(adUrl));
        if (!shouldBlock) {
            data.push(img.src);
        }
    });

    return Response.success(data);
}