load('config.js');

function execute(url) {
    const doc = fetch(url).html();

    const name = doc.select("h1").last().text().replace(/NEW |Ongoing /gi, '');
    const cover = doc.select('meta[property="og:image"]').attr("content");
    const description = doc.select(".summary-content p").html();
    const category = doc.select(".info-detail-comic .category").html();

    const author = doc.select("ul.info-detail-comic li.author .detail-info").text();
    const status = doc.select("ul.info-detail-comic li.status .detail-info").text();
    const translator = doc.select("ul.info-detail-comic li.translate-group .detail-info").text();
    const views = doc.select("ul.info-detail-comic li.view-total .detail-info").text();
    const likes = doc.select("ul.info-detail-comic li.view-like .detail-info").text();
    const follows = doc.select("ul.info-detail-comic li.total-follow .detail-info").text();

    const detail = "Tác giả: " + author + "<br>" + "Tình trạng: " + status + "<br>" + "Thể loại: " + category + "<br>" + "Nhóm dịch: " + translator + "<br>" + "Lượt xem: " + views + "<br>" + "Lượt thích: " + likes + "<br>" + "Theo dõi: " + follows;

    // Tạo mảng genres
    const genres = [];
    const genreElements = doc.select("ul.info-detail-comic li.category .detail-info .cat-detail a");

    for (var i = 0; i < genreElements.size(); i++) {
        var genreElement = genreElements.get(i);
        var inputLink = genreElement.attr("href");

        // Chỉ lấy phần từ /tim-truyen trở đi
        var input = inputLink.substring(inputLink.indexOf("/tim-truyen"));

        genres.push({
            title: genreElement.text(),
            input: input,
            script: "home1.js"
        });
    }

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        genres: genres,
        description: description,
        detail: detail,
        category: category,
        host: BASE_URL
    });
}