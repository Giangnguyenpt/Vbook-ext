let BASE_URL1 = 'https://www.toptruyenvn.pro';
let BASE_URL = 'https://doctruyen3qw.pro'
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}