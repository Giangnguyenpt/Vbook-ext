load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        const regex = /const\s+CHAPTER_ID\s*=\s*(\d+);/;
        const book_id = doc.html().match(regex)[1];
        let url2 = "https://nettruyenll.com/ajax/image/list/chap/" + book_id;
        let response2 = fetch(url2);
        if (response2.ok) {
            let doc2 = response2.json().html;
            let doc3 = Html.parse(doc2);
            let data = [];
            let shouldSort = true;

            // Collect all images and their data-index values
            let images = [];
            doc3.select(".page-chapter img").forEach(e => {
                let index = e.attr("data-index");
                let img = e.attr("data-original");
                if (index === undefined || img === undefined) {
                    shouldSort = false;
                    data.push(img);
                } else {
                    images.push({ index: parseInt(index), img });
                }
            });

            // Sort and push images if sorting is feasible
            if (shouldSort) {
                images.sort((a, b) => a.index - b.index);
                images.forEach(item => data.push(item.img));
            }

            return Response.success(data);
        }
    }
    return null;
}