load('config.js');
load('adblock.js'); // Load danh sách URL quảng cáo

function execute(url) {
    // Thay thế domain trong URL bằng BASE_URL từ config.js
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);

    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let data = [];

        // Duyệt qua tất cả các phần tử img trong trang
        doc.select(".page-chapter img").forEach(e => {
            // Lấy các liên kết hình ảnh từ thuộc tính src và data-src
            let src = e.attr("src");
            let dataSrc = e.attr("data-src");

            // Kiểm tra nếu URL hợp lệ và kết nối được, sau đó thêm vào data nếu không phải URL quảng cáo
            if (src && checkImageUrl(src) && !isAdUrl(src)) {
                data.push(src);
            }
            if (dataSrc && checkImageUrl(dataSrc) && !isAdUrl(dataSrc)) {
                data.push(dataSrc);
            }
        });

        // Trả về dữ liệu thành công nếu có hình ảnh hợp lệ
        return Response.success(data);
    }
    // Trả về null nếu không có kết quả
    return null;
}

// Hàm để kiểm tra kết nối đến URL hình ảnh
function checkImageUrl(url) {
    try {
        let headResponse = fetch(url, {
            method: 'HEAD'
        });

        return headResponse.ok;
    } catch (error) {
        // Nếu có lỗi, coi như kết nối không thành công
        return false;
    }
}

// Hàm để kiểm tra xem URL có phải là URL quảng cáo không
function isAdUrl(url) {
    return adblockUrls.some(adUrl => url.includes(adUrl));
}