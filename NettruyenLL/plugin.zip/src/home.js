load('config.js');
function execute() {
    return Response.success([
        {
        "title": "Manhua",
        "input": "https://nettruyenll.com/the-loai/manhua",
        "script": "gen.js"
    },
        {
        "title": "Huyền Huyễn",
        "input": "https://nettruyenll.com/the-loai/huyen-huyen",
        "script": "gen.js"
    },
        {title: "Mới cập nhật", input: BASE_URL + "/danh-sach-truyen/1/?sort=latest-updated", script: "gen.js"},
        {title: "Truyện mới", input: BASE_URL + "/danh-sach-truyen/1/?sort=release-date", script: "gen.js"},
        {title: "Top all", input: BASE_URL + "/danh-sach-truyen/1/?sort=views", script: "gen.js"},
        {title: "Top tháng", input: BASE_URL + "/danh-sach-truyen/1/?sort=views_month", script: "gen.js"},
        {title: "Top tuần", input: BASE_URL + "/danh-sach-truyen/1/?sort=views_week", script: "gen.js"},
        {title: "Top ngày", input: BASE_URL + "/danh-sach-truyen/1/?sort=views_day", script: "gen.js"},
        {title: "Theo dõi", input: BASE_URL + "/danh-sach-truyen/1/?sort=bookmarks", script: "gen.js"},
        {title: "Số chương", input: BASE_URL + "/danh-sach-truyen/1/?sort=chapters", script: "gen.js"}
    ]);
}